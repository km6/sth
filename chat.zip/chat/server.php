<?php

class server{
	private $userinfo;

	public function __construct($ip = '0.0.0.0',$port = 9501) {
		$server = new swoole_websocket_server($ip, $port);
		$server->on('open', function (swoole_websocket_server $server, $request) {
			$this->Open($server, $request);
		});
		$server->on('message', function (swoole_websocket_server $server, $frame) {
			$this->Message($server, $frame);
		});
		$server->on('close', function ($ser, $fd) {
			$this->Close($ser, $fd);
		});
		$server->start();
	}

	public function Open(swoole_websocket_server $server, $request) {
		echo "server: handshake success with fd{$request->fd}\n";//$request->fd 是客户端id
    	$this->userinfo[$request->fd] = '游客'.$request->fd;
	}

	public function Message(swoole_websocket_server $server, $frame) {
		echo "receive from {$frame->fd}:{$frame->data},opcode:{$frame->opcode},fin:{$frame->finish}\n";
	    //$frame->fd 是客户端id，$frame->data是客户端发送的数据
	    //服务端向客户端发送数据是用 $server->push( '客户端id' ,  '内容')
	    $data = json_decode($frame->data);

	    switch ($data->opcode) {
	    	case '1':
	    		foreach($server->connections as $fd){
	    			//$msg = array('date','username','content')
	    			$msg = $this->userinfo[$frame->fd].' '.date('Y-m-d H:i:s').'<br />'.$data->data;
			        $server->push($fd , $msg);//循环广播
			    }
	    		break;

	    	case '2':
	    		$msg = $this->userinfo[$frame->fd].'已改名为'.$data->data;
	    		$this->userinfo[$frame->fd] = $data->data;
	    		foreach($server->connections as $fd){
	    			$server->push($fd , $msg);//循环广播
	    		}
	    		break;

	    	case '3':
	    		foreach($server->connections as $fd){
	    			//$msg = array('date','username','content')
	    			$msg = $data->data;
			        $server->push($fd , $msg);//循环广播
			    }
	    		break;
	    	
	    	default:
	    		# code...
	    		break;
	    }
	}

	public function Close($ser, $fd) {
		echo "client {$fd} closed\n";
	}
}

$server = new server('0.0.0.0', 1997);